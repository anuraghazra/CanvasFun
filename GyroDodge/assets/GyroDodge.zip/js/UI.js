
// document.body.onclick = () => {
//   toggleFullScreen()
//   ww = window.innerWidth;
//   wh = window.innerHeight;
// }
// function toggleFullScreen() {
//   var doc = window.document;
//   var docEl = doc.documentElement;
//   var requestFullScreen = docEl.requestFullscreen || docEl.mozRequestFullScreen || docEl.webkitRequestFullScreen || docEl.msRequestFullscreen;
//   if (!doc.fullscreenElement && !doc.mozFullScreenElement && !doc.webkitFullscreenElement && !doc.msFullscreenElement) {
//     requestFullScreen.call(docEl);
//   }
// }